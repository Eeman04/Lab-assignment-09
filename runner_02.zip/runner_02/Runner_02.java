/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner_02;
public class Runner_03 {

    public static void main(String[] args) {
            
            
            //creating Objects of PhdStudent class and GradStudent class
            PhdStudent s1=new PhdStudent();
            GradeStudent s2=new GradeStudent();
            //calling takeXam method from two Objects
            s1.takeXam();
            s2.takeXam();
        }
            
    }
    
    

