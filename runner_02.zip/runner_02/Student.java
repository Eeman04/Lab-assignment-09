/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner_02;

public abstract class Student {
        //takeXam method that prints message
    public void takeXam(){
        System.out.println("Taking Xam!");
    
}
}