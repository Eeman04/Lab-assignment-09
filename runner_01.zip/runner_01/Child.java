/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner_01;

public class Child extends Clock {
    
       //inheriting the Clock constructor
    
    public Child(String hours, String minutes, String seconds){
        super(hours, minutes, seconds);
    }
    //Overriding the display method of Clock class
    @Override
    public void display(){
        //displaying 24 hour format by calling super class display method
        System.out.println("24 Hour Format:");
        super.display();
        System.out.println("12 Hour Format:");
        //converting 24 hour format to 12 hour format and printing it
        int hour1 = (int)hours.charAt(0) - '0';
        int hour2 = (int)hours.charAt(1)- '0';
        int totalhour = hour1 * 10 + hour2;
        String m;
        if(totalhour < 12)
            m="AM";
        else
            m="PM";
        totalhour %= 12;
        if (totalhour == 0) {
            System.out.print("12");
            System.out.print(":"+minutes+":"+seconds);
        }
        else{
            System.out.print(totalhour);
            System.out.print(":"+minutes+":"+seconds);
        }
        System.out.println(" "+m);
    }
}

