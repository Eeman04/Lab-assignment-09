/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner_01;

public class Runner_01 {

    public static void main(String[] args) {
      
   //creating ChildClock class Object
            Child time=new Child("00","35","30");
            //calling display method
            time.display();
        }

    }
    

