/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner_03;

public class Runner_03 {

    public static void main(String[] args) {
    CustomStringTokenizer a = new CustomStringTokenizer( "there are 6 cycles");
        System.out.println("Count: "+a.countTokens());
    }  
    }
    
